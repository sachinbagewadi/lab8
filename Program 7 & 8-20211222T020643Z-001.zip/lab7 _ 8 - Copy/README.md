# PWA-Login
A simple login website with PWA features.

# Install npm in Ubuntu
sudo apt install npm

# Install nodejs in Ubuntu
sudo apt install nodejs

# To check the npm version
npm -v

# To check the node version
node -v

# Commands to run 
npm init
node server.js



